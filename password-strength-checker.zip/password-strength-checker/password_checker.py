
import re
import sys
from pathlib import Path

COMMON_LIST = Path(__file__).parent / "common_passwords.txt"

def load_common_passwords():
    if COMMON_LIST.exists():
        with COMMON_LIST.open("r", encoding="utf-8") as f:
            return set(p.strip() for p in f if p.strip())
    return set()

def check_password_strength(password: str, common_set: set) -> dict:
    checks = {
        "length>=12": len(password) >= 12,
        "has_digit": bool(re.search(r"\d", password)),
        "has_upper": bool(re.search(r"[A-Z]", password)),
        "has_lower": bool(re.search(r"[a-z]", password)),
        "has_symbol": bool(re.search(r"[!@#$%^&*()_+\-={}[\]|:;"'<>,.?/`~]", password)),
        "not_common": password not in common_set
    }
    score = sum(checks.values())
    rating = "Weak"
    if score >= 5: rating = "Strong"
    elif score == 4: rating = "Moderate"
    return {"score": score, "rating": rating, "checks": checks}

def suggestions(checks: dict) -> list:
    tips = []
    if not checks["length>=12"]:
        tips.append("Use at least 12 characters.")
    if not checks["has_digit"]:
        tips.append("Add at least one number.")
    if not checks["has_upper"]:
        tips.append("Add an uppercase letter.")
    if not checks["has_lower"]:
        tips.append("Add a lowercase letter.")
    if not checks["has_symbol"]:
        tips.append("Include a symbol like ! or %.")
    if not checks["not_common"]:
        tips.append("Avoid common passwords or dictionary words.")
    return tips

if __name__ == "__main__":
    if len(sys.argv) == 2:
        pwd = sys.argv[1]
    else:
        pwd = input("Enter a password to evaluate: ")
    common = load_common_passwords()
    result = check_password_strength(pwd, common)
    print(f"Rating: {result['rating']} (score {result['score']}/6)")
    for k, v in result["checks"].items():
        print(f" - {k}: {'OK' if v else 'X'}")
    if result["rating"] != "Strong":
        print("\nSuggestions:")
        for tip in suggestions(result["checks"]):
            print(" *", tip)
