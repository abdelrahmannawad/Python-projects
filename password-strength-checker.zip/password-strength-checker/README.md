
# Password Strength Checker

A simple Python tool that scores a password on 6 criteria and gives improvement tips.

## Features
- Length, digits, uppercase, lowercase, symbols, and common-password check
- CLI usage with interactive input or command-line arg

## How to Run
```bash
python3 password_checker.py "YourPassword123!"
# or
python3 password_checker.py
```

## Educational Notes
- Demonstrates regex, file I/O, and simple scoring logic
- Great starter project for a security-focused portfolio
