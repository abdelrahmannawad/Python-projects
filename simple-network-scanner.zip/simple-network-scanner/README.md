
# Simple Network Scanner (Educational)

Pings every host in a given CIDR (e.g., `192.168.1.0/24`) and lists responsive IPs.

> **Ethical use only**: Scan only networks you own or have explicit permission to test.

## How to Run
```bash
python3 network_scanner.py
# Enter your local subnet, e.g., 192.168.1.0/24
```

## Educational Notes
- Demonstrates concurrency with `ThreadPoolExecutor`
- Teaches basic networking and ICMP-based host discovery
- A stepping stone to more advanced tools using `scapy`/`nmap`
