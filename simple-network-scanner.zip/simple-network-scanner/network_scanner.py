
import ipaddress
import platform
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

# WARNING: Only scan networks you own or have permission to test.

def ping(host: str, timeout_ms: int = 500) -> bool:
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout_ms), host]
    else:
        # On Unix, timeout is in seconds, so convert
        cmd = ["ping", "-c", "1", "-W", str(int(timeout_ms/1000) or 1), host]
    try:
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return res.returncode == 0
    except Exception:
        return False

def scan_subnet(cidr: str, max_workers: int = 100):
    net = ipaddress.ip_network(cidr, strict=False)
    online = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(ping, str(ip)): str(ip) for ip in net.hosts()}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                if fut.result():
                    online.append(ip)
                    print(f"[+] {ip} is up")
            except Exception:
                pass
    return online

if __name__ == "__main__":
    print("Simple Network Scanner (educational use only)")
    cidr = input("Enter CIDR (e.g., 192.168.1.0/24): ").strip()
    hosts = scan_subnet(cidr)
    print("\nOnline hosts:")
    for h in hosts:
        print(" -", h)
