
import os
import shutil
from pathlib import Path

# Map file extensions to target folders
CATEGORIES = {
    "Images": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"},
    "Documents": {".pdf", ".docx", ".doc", ".txt", ".md", ".pptx", ".xlsx", ".csv"},
    "Audio": {".mp3", ".wav", ".m4a", ".flac"},
    "Video": {".mp4", ".mov", ".avi", ".mkv"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz"},
    "Code": {".py", ".java", ".cpp", ".c", ".js", ".html", ".css", ".ipynb"},
}

def categorize(path: Path) -> str:
    ext = path.suffix.lower()
    for folder, exts in CATEGORIES.items():
        if ext in exts:
            return folder
    return "Other"

def organize(directory: Path):
    if not directory.exists():
        raise FileNotFoundError(f"{directory} does not exist")
    for item in directory.iterdir():
        if item.is_file():
            target_folder = directory / categorize(item)
            target_folder.mkdir(exist_ok=True)
            shutil.move(str(item), target_folder / item.name)
    print(f"Organized files in {directory}")

if __name__ == "__main__":
    target = Path(input("Folder to organize (e.g., ~/Downloads): ")).expanduser()
    organize(target)
