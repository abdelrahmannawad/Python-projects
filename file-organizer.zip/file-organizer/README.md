
# File Organizer

Automatically sorts files into folders (Images, Documents, Code, etc.).

## How to Run
```bash
python3 file_organizer.py
# Then enter a path, e.g., ~/Downloads
```

## Educational Notes
- Demonstrates filesystem operations with `pathlib` and `shutil`
- Useful automation project to show practical skills
